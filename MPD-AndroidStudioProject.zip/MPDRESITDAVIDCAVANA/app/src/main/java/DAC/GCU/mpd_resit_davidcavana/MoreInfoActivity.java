//DAVID ALEXANDER CAVANA - S1826065

package DAC.GCU.mpd_resit_davidcavana;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mpd_resit_davidcavana.R;

import java.util.LinkedList;

public class MoreInfoActivity extends AppCompatActivity {

    //App Objects
    private TextView textViewCurrentLocation;
    private TextView textViewDay;
    private TextView textViewWeather;
    private TextView textViewTemperatures;
    private TextView textViewWindSpeed;
    private TextView textViewWindDir;
    private TextView textViewVis;
    private TextView textViewPres;
    private TextView textViewHum;
    private TextView textViewUV;
    private TextView textViewPoll;
    private TextView textViewSunrise;
    private TextView textViewSunset;
    private Button buttonBack;
    private Intent mainActivityIntent;

    int day;
    String currentLocation;
    String result;
    MainActivity mainActivity = new MainActivity();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forecast_more_info);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            currentLocation = extras.getString("location");
            result = extras.getString("result");
            day = extras.getInt("day");
        }

        mainActivityIntent = new Intent(MoreInfoActivity.this, MainActivity.class);

        textViewCurrentLocation = (TextView) findViewById(R.id.currentLocation);
        textViewDay = (TextView) findViewById(R.id.currentDay);
        textViewWeather = (TextView) findViewById(R.id.currentWeather);
        textViewTemperatures = (TextView) findViewById(R.id.temperatures);
        textViewWindSpeed = (TextView) findViewById(R.id.windSpeed);
        textViewWindDir = (TextView) findViewById(R.id.windDirection);
        textViewVis = (TextView) findViewById(R.id.visibility);
        textViewPres = (TextView) findViewById(R.id.pressure);
        textViewHum = (TextView) findViewById(R.id.humidity);
        textViewUV = (TextView) findViewById(R.id.UVRisk);
        textViewPoll = (TextView) findViewById(R.id.pollution);
        textViewSunrise = (TextView) findViewById(R.id.sunriseTime);
        textViewSunset = (TextView) findViewById(R.id.sunsetTime);

        buttonBack = (Button) findViewById(R.id.buttonBack);

        //Go back to main screen
        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainActivity();
            }
        });

        textViewCurrentLocation.setText(currentLocation);

        LinkedList<LocationForecast> alist = null;
        alist = mainActivity.parseData(result);

        switch (day) {
            case 0:
            case 2:
                textViewDay.setText(alist.get(day).getDay());
                break;
            case 1:
                textViewDay.setText("Tomorrow");
                break;
        }

        textViewWeather.setText(alist.get(day).getCurrentWeather());
        textViewTemperatures.setText(alist.get(day).getTemperatures());
        textViewWindSpeed.setText("Wind Speed: " + alist.get(day).getWindSpeed());
        textViewWindDir.setText("Wind Direction: " + alist.get(day).getWindDirection());
        textViewVis.setText("Visibility: " + alist.get(day).getVisibility());
        textViewPres.setText("Pressure: " + alist.get(day).getPressure());
        textViewHum.setText("Humidity: " + alist.get(day).getHumidity());
        textViewUV.setText("UV Risk: " + alist.get(day).getUVRisk());
        textViewPoll.setText("Pollution: " + alist.get(day).getPollution());
        textViewSunset.setText("Sunset: " + alist.get(day).getSunsetTime());

        if (alist.get(day).getSunriseTime() != null) {
            textViewSunrise.setText("Sunrise: " + alist.get(day).getSunriseTime());
        } else {
            textViewSunrise.setText("");
        }
    }

    public void openMainActivity() {
        startActivity(mainActivityIntent);
    }
}
