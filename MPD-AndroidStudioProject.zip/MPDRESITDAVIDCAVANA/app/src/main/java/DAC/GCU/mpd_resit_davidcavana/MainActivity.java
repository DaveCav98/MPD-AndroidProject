//DAVID ALEXANDER CAVANA - S1826065

package DAC.GCU.mpd_resit_davidcavana;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mpd_resit_davidcavana.R;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.TimeZone;

public class MainActivity extends AppCompatActivity {
    private ArrayList<LocationSpinnerItem> spinnerLocationList; //List of options available in spinner
    private LocationAdapter adapter;
    private String result;

    //App Objects
    private Spinner locationSpinner;
    private TextView[] textViewDay = new TextView[3];
    private TextView[] textViewWeather = new TextView[3];
    private TextView[] textViewTemperatures = new TextView[3];
    private TextView[] textViewWindSpeed = new TextView[3];
    private Button[] buttonMoreInfo = new Button[3];

    //URL Variables
    private String urlSource = "https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/";
    private String currentLocationID;
    private String currentLocationURL;
    private String clickedLocationName;

    private String[] locationNames = {"Glasgow", "London", "New York", "Muscat", "Port Louis", "Dhaka"}; //Do not delete
    private static final String TAG = "MyActivity";
    private Intent moreInfoIntent;

    //Timezone Variables
    private String[] currentTime = new String[6];
    private String[] formattedDate = new String[6];
    private SimpleDateFormat df;
    private Calendar c;
    private boolean run = true;
    private Handler mHandler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        moreInfoIntent = new Intent(MainActivity.this, MoreInfoActivity.class);

        initList();
        updateTimeZones();
        startTimer();
        initObjects();

        adapter = new LocationAdapter(this, spinnerLocationList);
        locationSpinner.setAdapter(adapter);

        locationSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                LocationSpinnerItem clickedItem = (LocationSpinnerItem) parent.getItemAtPosition(pos);
                clickedLocationName = clickedItem.getLocationName();
                Log.e("Current Location", clickedLocationName);

                //Pass current location to MoreInfoActivity
                moreInfoIntent.putExtra("location", clickedLocationName);

                Toast.makeText(MainActivity.this, clickedLocationName + " selected", Toast.LENGTH_SHORT).show();

                SelectID(pos);
                Log.e("Location ID", currentLocationID);

                currentLocationURL = urlSource + currentLocationID;
                Log.e("Location URL", currentLocationURL);

                // Run network access on a separate thread;
                new Thread(new Task(currentLocationURL)).start();

                //Log.e(TAG, "Current Location ID:" + currentLocationID);
                //Log.e(TAG, "Current Location URL:" + currentLocationURL);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        for (int i = 0; i < buttonMoreInfo.length; i++) {
            final int day = i;
            buttonMoreInfo[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    moreInfoIntent.putExtra("day", day);
                    openMoreInfo();
                }
            });
        }
    }

    public void openMoreInfo() {
        startActivity(moreInfoIntent);
    }

    public void initObjects() {
        locationSpinner = (Spinner) findViewById(R.id.locationSelection);

        //First Day
        textViewDay[0] = (TextView) findViewById(R.id.currentDay);
        textViewWeather[0] = (TextView) findViewById(R.id.currentWeather);
        textViewTemperatures[0] = (TextView) findViewById(R.id.temperatures);
        textViewWindSpeed[0] = (TextView) findViewById(R.id.windSpeed);
        buttonMoreInfo[0] = (Button) findViewById(R.id.currentForecastMoreInfo);
        //Second Day
        textViewDay[1] = (TextView) findViewById(R.id.secondDay);
        textViewWeather[1] = (TextView) findViewById(R.id.secondWeather);
        textViewTemperatures[1] = (TextView) findViewById(R.id.secondTemperatures);
        textViewWindSpeed[1] = (TextView) findViewById(R.id.secondWindSpeed);
        buttonMoreInfo[1] = (Button) findViewById(R.id.secondForecastMoreInfo);
        //Third Day
        textViewDay[2] = (TextView) findViewById(R.id.thirdDay);
        textViewWeather[2] = (TextView) findViewById(R.id.thirdWeather);
        textViewTemperatures[2] = (TextView) findViewById(R.id.thirdTemperatures);
        textViewWindSpeed[2] = (TextView) findViewById(R.id.thirdWindSpeed);
        buttonMoreInfo[2] = (Button) findViewById(R.id.thirdForecastMoreInfo);
    }

    private void initList() {
        spinnerLocationList = new ArrayList<>();

        spinnerLocationList.add(new LocationSpinnerItem(locationNames[0], R.drawable.scotland, currentTime[0]));
        spinnerLocationList.add(new LocationSpinnerItem(locationNames[1], R.drawable.england, currentTime[1]));
        spinnerLocationList.add(new LocationSpinnerItem(locationNames[2], R.drawable.america, currentTime[2]));
        spinnerLocationList.add(new LocationSpinnerItem(locationNames[3], R.drawable.oman, currentTime[3]));
        spinnerLocationList.add(new LocationSpinnerItem(locationNames[4], R.drawable.mauritius, currentTime[4]));
        spinnerLocationList.add(new LocationSpinnerItem(locationNames[5], R.drawable.bangladesh, currentTime[5]));
    }

    public void startTimer() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (run) {
                    try {
                        Thread.sleep(20000);
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                updateTimeZones();
                            }
                        });
                    } catch (Exception e) {

                    }
                }
            }
        }).start();
    }

    public void updateTimeZones() {
        TimeZone UK = TimeZone.getTimeZone("Europe/London");
        c = Calendar.getInstance(UK);
        df = new SimpleDateFormat("HH:mm");
        df.setTimeZone(UK);
        formattedDate[0] = df.format(c.getTime());
        formattedDate[1] = df.format(c.getTime());
        currentTime[0] = formattedDate[0];
        currentTime[1] = formattedDate[1];

        TimeZone NY = TimeZone.getTimeZone("America/New_York");
        c = Calendar.getInstance(NY);
        df.setTimeZone(NY);
        formattedDate[2] = df.format(c.getTime());
        currentTime[2] = formattedDate[2];

        TimeZone OM = TimeZone.getTimeZone("Asia/Muscat");
        c = Calendar.getInstance(OM);
        df.setTimeZone(OM);
        formattedDate[3] = df.format(c.getTime());
        formattedDate[4] = df.format(c.getTime());
        currentTime[3] = formattedDate[3];
        currentTime[4] = formattedDate[4];

        TimeZone BA = TimeZone.getTimeZone("Asia/Dhaka");
        c = Calendar.getInstance(BA);
        df.setTimeZone(BA);
        formattedDate[5] = df.format(c.getTime());
        currentTime[5] = formattedDate[5];

        for (int i = 0; i < locationNames.length; i++) {
            spinnerLocationList.get(i).setCurrentTime(currentTime[i]);
        }
    }

    public void SelectID(int selection) {
        switch (selection) {
            case 0:
                currentLocationID = "2648579"; //Glasgow
                break;
            case 1:
                currentLocationID = "2643743"; //London
                break;
            case 2:
                currentLocationID = "5128581"; //New York
                break;
            case 3:
                currentLocationID = "287286"; //Oman
                break;
            case 4:
                currentLocationID = "934154"; //Mauritius
                break;
            case 5:
                currentLocationID = "1185241"; //Bangladesh
                break;
        }
    }

    private class Task implements Runnable {
        private String url;

        public Task(String aurl) {
            url = aurl;
        }

        @Override
        public void run() {
            URL aurl;
            URLConnection yc;
            BufferedReader in = null;
            String inputLine = "";

            try {
                aurl = new URL(url);
                yc = aurl.openConnection();
                in = new BufferedReader(new InputStreamReader(yc.getInputStream(), "UTF-8"));

                result = "";

                while ((inputLine = in.readLine()) != null) {
                    result += inputLine;
                    result = result.replaceAll("[^\\x20-\\x7e]", ""); //Replace any unneeded characters
                    result = result.replaceAll("\uFEFF", "");
                }
                in.close();

                moreInfoIntent.putExtra("result", result);
            } catch (IOException ae1) {
                System.out.println("IO error during parsing");
            }

            MainActivity.this.runOnUiThread(new Runnable() {
                public void run() {

                    LinkedList<LocationForecast> alist = null;
                    alist = parseData(result);
                    for (int i = 0; i < alist.size(); i++) {
                        textViewDay[i].setText(alist.get(i).getDay());
                        textViewWeather[i].setText(alist.get(i).getCurrentWeather());
                        textViewTemperatures[i].setText(alist.get(i).getTemperatures());
                        textViewWindSpeed[i].setText("Wind Speed: " + alist.get(i).getWindSpeed());
                    }

                    textViewDay[1].setText("Tomorrow");

                    // Write list to Log for testing
                if (alist != null) {
                    Log.e("Parse Testing", "List not null");
                    for (Object o : alist) {
                        Log.e("Parsed Object Testing", o.toString());
                    }
                } else {
                    Log.e("Parse Testing", "aList is null");
                }

                }
            });
        }

    }

    public LinkedList<LocationForecast> parseData(String dataToParse) {
        LocationForecast locationForecast = null;
        LinkedList<LocationForecast> alist = null;

        try {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser xpp = factory.newPullParser();
            xpp.setInput(new StringReader(dataToParse));

            boolean insideItem = false;

            int eventType = xpp.getEventType();
            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_TAG:
                        if (xpp.getName().equalsIgnoreCase("channel")) {
                            Log.e("Parse Start", "List is created");
                            alist = new LinkedList<LocationForecast>();
                        } else if (xpp.getName().equalsIgnoreCase("item")) {
                            insideItem = true;
                            Log.e("Parsing", "Item Start Tag found");
                            locationForecast = new LocationForecast();

                        } else if (xpp.getName().equalsIgnoreCase("title")) {
                            if (insideItem) {
                                String temp = xpp.nextText();

                                //Set Day
                                String[] day = temp.split(":");
                                Log.e("Day", day[0]);
                                locationForecast.setDay(day[0]);

                                //Set Weather
                                String[] currentWeather = day[1].split(", ");
                                Log.e("Current Weather", currentWeather[0]);
                                locationForecast.setCurrentWeather(currentWeather[0]);

                                //Set Temperatures
                                //First Day - After a certain time during the day, the first day in the XML file will stop displaying two temperatures
                                if (!temp.contains("Maximum")) {
                                    String[] temps = temp.split("C "); //Split the two celsius temperatures
                                    temps[0] = temps[0].replaceAll("[^\\d.]", ""); //Remove all non numeric characters
                                    Log.e("Min Temperatures", temps[0]);
                                    locationForecast.setTemperatures("MIN " + temps[0] + "°C");
                                }
                                //Other Days - Will always display two temperatures
                                else {
                                    String[] temps = temp.split("Maximum"); //Get two temperatures seperated
                                    String[] minCelsius = temps[0].split("C "); //Split the two minimum celsius temperatures
                                    String[] maxCelsius = temps[1].split("C "); //Split the two maximum celsius temperatures
                                    minCelsius[0] = minCelsius[0].replaceAll("[^\\d.]", ""); //Remove all non numeric characters
                                    maxCelsius[0] = maxCelsius[0].replaceAll("[^\\d.]", ""); //Remove all non numeric characters
                                    Log.e("Min Temperatures", minCelsius[0]);
                                    Log.e("Max Temperatures", maxCelsius[0]);
                                    locationForecast.setTemperatures(minCelsius[0] + "°C - " + maxCelsius[0] + "°C");
                                }


                            }
                        } else if (xpp.getName().equalsIgnoreCase("description")) {
                            if (insideItem) {
                                String temp = xpp.nextText();
                                //Log.e("Parsed Data - Desc", temp);

                                //Set Wind Direction
                                String[] splitAtWindDir = temp.split("Wind Direction: ");
                                String[] windDirection = splitAtWindDir[1].split(", ");
                                Log.e("Wind Direction", windDirection[0]);
                                locationForecast.setWindDirection(windDirection[0]);

                                //Set Wind Speed
                                String[] splitAtWindSpeed = splitAtWindDir[1].split("Wind Speed: ");
                                String[] windSpeed = splitAtWindSpeed[1].split(", ");
                                Log.e("Wind Speed", windSpeed[0]);
                                locationForecast.setWindSpeed(windSpeed[0]);

                                //Set Visiblity
                                String[] splitAtVisibility = splitAtWindSpeed[1].split("Visibility: ");
                                String[] visibility = splitAtVisibility[1].split(", ");
                                Log.e("Visibility", visibility[0]);
                                locationForecast.setVisibility(visibility[0]);

                                //Set Pressure
                                String[] splitAtPressure = splitAtVisibility[1].split("Pressure: ");
                                String[] pressure = splitAtPressure[1].split(", ");
                                Log.e("Pressure", pressure[0]);
                                locationForecast.setPressure(pressure[0]);

                                //Set Humidity
                                String[] splitAtHumidity = splitAtPressure[1].split("Humidity: ");
                                String[] humidity = splitAtHumidity[1].split(", ");
                                Log.e("Humidity", humidity[0]);
                                locationForecast.setHumidity(humidity[0]);

                                //Set UV Risk
                                String[] splitAtUVRisk = splitAtHumidity[1].split("UV Risk: ");
                                String[] UVRisk = splitAtUVRisk[1].split(", ");
                                Log.e("UV Risk", UVRisk[0]);
                                locationForecast.setUVRisk(UVRisk[0]);

                                //Set Pollution
                                String[] splitAtPollution = splitAtUVRisk[1].split("Pollution: ");
                                String[] pollution = splitAtPollution[1].split(", ");
                                Log.e("Pollution", pollution[0]);
                                locationForecast.setPollution(pollution[0]);

                                //Set Sunset on first day - After a certain time during the day, the first day in the XML file will only display sunset
                                String[] splitAtSunset = splitAtPollution[1].split("Sunset: ");
                                if (!temp.contains("Sunrise: ")) {
                                    Log.e("Sunset", splitAtSunset[1]);
                                    locationForecast.setSunsetTime(splitAtSunset[1]);
                                } else {
                                    //Set Sunrise
                                    String[] splitAtSunrise = splitAtPollution[1].split("Sunrise: ");
                                    Log.e("Sunrise", splitAtSunrise[1]);

                                    String[] sunrise = splitAtSunrise[1].split(", ");
                                    Log.e("Sunrise", sunrise[0]);
                                    Log.e("Sunset", splitAtSunset[1]);
                                    locationForecast.setSunsetTime(splitAtSunset[1]);
                                    locationForecast.setSunriseTime(sunrise[0]);
                                }
                            }
                        }
                        break;
                    case XmlPullParser.END_TAG:
                        if (xpp.getName().equalsIgnoreCase("item")) {
                            //Log.e("Parsing", "locationForecast is " + locationForecast.toString());
                            alist.add(locationForecast);
                            insideItem = false;
                            Log.e("Parsing", "Item End Tag found");
                        } else if (xpp.getName().equalsIgnoreCase("channel")) {
                            int size;
                            size = alist.size();
                            Log.e("Parse End", "locationForecastcollection size is " + size);
                        }
                        break;
                }
                eventType = xpp.next();
            }

        } catch (XmlPullParserException ae1) {
            Log.e("MyTag", "Parsing error " + ae1.toString());
        } catch (IOException ae1) {
            Log.e("MyTag", "IO error during parsing");
        }
        return alist;
    }
} // End of MainActivity