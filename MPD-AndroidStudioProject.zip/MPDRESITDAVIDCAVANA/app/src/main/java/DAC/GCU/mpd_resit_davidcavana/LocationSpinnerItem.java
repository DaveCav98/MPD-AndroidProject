//DAVID ALEXANDER CAVANA - S1826065

package DAC.GCU.mpd_resit_davidcavana;

public class LocationSpinnerItem {
    private String mLocationName;
    private int mFlagIcon;
    private String mCurrentTime;

    public LocationSpinnerItem(String locationName, int flagIcon, String currentTime) {
        mLocationName = locationName;
        mFlagIcon = flagIcon;
        mCurrentTime = currentTime;
    }

    public String getLocationName() {
        return mLocationName;
    }

    public int getFlagIcon() {
        return mFlagIcon;
    }

    public String getCurrentTime() {
        return mCurrentTime;
    }

    public void setCurrentTime(String currentTime) {
        this.mCurrentTime = currentTime;
    }
}
