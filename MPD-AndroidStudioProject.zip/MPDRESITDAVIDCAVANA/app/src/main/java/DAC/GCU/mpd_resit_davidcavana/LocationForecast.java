//DAVID ALEXANDER CAVANA - S1826065

package DAC.GCU.mpd_resit_davidcavana;

public class LocationForecast {
    private String mCurrentWeather;
    private String mDay;
    private String mTemperatures;
    private String mWindSpeed;

    //More Detailed Weather Information
    private String mWindDirection;
    private String mVisibility;
    private String mPressure;
    private String mHumidity;
    private String mUVRisk;
    private String mPollution;
    private String mSunriseTime;
    private String mSunsetTime;

    //Getters
    public String getCurrentWeather() {
        return mCurrentWeather;
    }

    public String getDay() {
        return mDay;
    }

    public String getTemperatures() {
        return mTemperatures;
    }

    public String getWindSpeed() {
        return mWindSpeed;
    }

    public String getWindDirection() {
        return mWindDirection;
    }

    public String getVisibility() {
        return mVisibility;
    }

    public String getPressure() {
        return mPressure;
    }

    public String getHumidity() {
        return mHumidity;
    }

    public String getUVRisk() {
        return mUVRisk;
    }

    public String getPollution() {
        return mPollution;
    }

    public String getSunriseTime() {
        return mSunriseTime;
    }

    public String getSunsetTime() {
        return mSunsetTime;
    }

    //Setters
    public void setCurrentWeather(String currentWeather) {
        this.mCurrentWeather = currentWeather;
    }

    public void setDay(String day) {
        this.mDay = day;
    }

    public void setTemperatures(String temperatures) {
        this.mTemperatures = temperatures;
    }

    public void setWindSpeed(String windSpeed) {
        this.mWindSpeed = windSpeed;
    }

    public void setWindDirection(String windDirection) {
        this.mWindDirection = windDirection;
    }

    public void setVisibility(String visibility) {
        this.mVisibility = visibility;
    }

    public void setPressure(String pressure) {
        this.mPressure = pressure;
    }

    public void setHumidity(String humidity) {
        this.mHumidity = humidity;
    }

    public void setUVRisk(String UVRisk) {
        this.mUVRisk = UVRisk;
    }

    public void setPollution(String pollution) {
        this.mPollution = pollution;
    }

    public void setSunriseTime(String sunriseTime) {
        this.mSunriseTime = sunriseTime;
    }

    public void setSunsetTime(String sunsetTime) {
        this.mSunsetTime = sunsetTime;
    }
}
